package com.example.inventory.InventoryManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventory.InventoryManagement.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
	 List<Order> findByCustomerName(String customerName);
}
